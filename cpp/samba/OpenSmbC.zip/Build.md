How To Build
------------
To build this library the folloing packages are required :-
1. CMAKE -- 2.8 or higher
2. OpenSSL
3. C++ 11

Once these packages are installed, do the following
1. cd build
2. cmake ..
3. make

