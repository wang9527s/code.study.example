# OpenSmbC
SMB Client Library
------------------
This is a c++ SMB client library and currently supports SMB 2(All versions), SMB 3(all versions) including SMB 3.11
